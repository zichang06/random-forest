# GBDT

参考了[bluekingsong](https://github.com/bluekingsong/simple-gbdt)和[qiyiping](https://github.com/qiyiping/gbdt)的实现  

实现了regression、binary classification、multi-calss classification

相关公式可以参考我整理的[GBDT.ipynb文件](http://nbviewer.ipython.org/github/liudragonfly/GBDT/blob/master/GBDT.ipynb)

在data目录下提供了一个测试数据集
